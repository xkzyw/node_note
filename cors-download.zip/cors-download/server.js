const express = require('express');
const app = express();
const port = 3000;

// Usare il modulo cors()
app.use(cors());

// Abilitare tutti i domini
app.options("*", cors());

app.listen(port, () => {
    console.log(`Server on http://localhost:${port}`);
});