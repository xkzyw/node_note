let fs = require("fs")

fs.writeFileSync("test.txt", "hello world");

console.log(fs.readFileSync("test.txt"));