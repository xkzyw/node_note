import http from "http";
import url from "url";

let server = http.createServer((req, res) => {
    let urlContent = url.parse(req.url, true);

    let path = urlContent.pathname;

    switch(path){
        case "/":
            res.end("root");
            break;
        case "/richiedePrenotazione":
            res.end("richiede prenotazione");
            break;
    }

});

server.listen(3000);