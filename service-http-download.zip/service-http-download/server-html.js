import http from "http";

// In questo esempio, il server ritorna 
// dei codice html.

let server = http.createServer((req, res) => {
    res.setHeader("ContentType", "text/html");
    res.write("<h1>Hello world</h1>");
    res.end();
});

server.listen(3000);