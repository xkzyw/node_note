import http from "http";

// In questo esempio, il server ritorna solamente
// testo puro

let server = http.createServer((req, res) => {
    res.write("Hello world");
    res.end();
});

server.listen(3000);