const express = require('express');
const app = express();
const port = 3001;

//per mappare su /
app.use("/", express.static(__dirname + "/static"));

app.listen(port, () => {
    console.log("server on")
})

app.get("/", (req, res) => {
    res.sendFile(__dirname + "/index.html");
});