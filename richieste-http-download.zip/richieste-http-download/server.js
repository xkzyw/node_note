const express = require('express');
const app = express();
const port = 3001;

// configurazione per usare il modulo express.json
app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.listen(port, () => {
    console.log(`Server on http://localhost:${port}`);
});

app.get("/", (req, res) => {
    res.send("Hello express");
});

app.post("/post", (req, res) => {
    res.send(req.body.name);
});