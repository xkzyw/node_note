const express = require("express");
const app = express();
const port = 3000;

app.set("views", "./view");
app.set("view engine", "ejs");

app.use(express.json());
app.use(express.urlencoded({
    extended: true
}));

app.get("/", (req, res) => {
    let persona = {
        nome: "mario",
        cognome: "rossi",
        cf: "dssfasf"
    };

    res.render("index", {
        msg: persona
    });
});

app.post("/recupera", (req, res) => {
    let persona = {
        nome: req.body.nome,
        cognome: req.body.cognome,
        cf: req.body.cf
    };

    res.render("index", {
        msg: persona
    });
});

app.listen(port, () => {});