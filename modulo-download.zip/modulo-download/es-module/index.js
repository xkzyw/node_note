import mod from "./mod.js"

console.log(mod.sum(1, 2));