let mod = require("./mod")

console.log(mod.sum(1, 2));